# DeWalt Train Horn - Product Landing & Review Website

## Overview

This is a modern full-stack web application built as a product-oriented landing page and review site for DeWalt train horns. The application serves as an affiliate marketing website that provides comprehensive product information, reviews, and buying guides to drive traffic to the main retailer (BossHorn.com).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **Styling**: Tailwind CSS with custom DeWalt-branded color scheme (yellow/black)
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state management
- **Build Tool**: Vite for fast development and optimized production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM (currently using in-memory storage as placeholder)
- **Session Management**: Prepared for connect-pg-simple with PostgreSQL
- **Development**: Hot module replacement via Vite integration

### Key Design Decisions

**Frontend-Heavy Architecture**: The application is primarily client-side rendered with minimal backend API usage, focusing on static content delivery and SEO optimization.

**Affiliate Marketing Focus**: The entire application is designed around driving users to external purchase links using JavaScript onclick handlers instead of direct links, as specified in client requirements.

**SEO-First Approach**: Comprehensive SEO optimization including schema markup, meta tags, canonical URLs, and structured data for better search engine visibility.

## Key Components

### Content Management
- **Article System**: Dynamic article rendering with SEO optimization
- **Product Comparison**: Interactive comparison tables for DeWalt train horn models
- **Author Profiles**: Expert credibility with author information and bios
- **Comment System**: User engagement with comment forms and moderation

### User Interface
- **Responsive Design**: Mobile-first approach with breakpoint-specific layouts
- **Component Library**: Consistent design system using shadcn/ui components
- **Loading States**: Smooth user experience with proper loading and error states
- **Toast Notifications**: User feedback for form submissions and interactions

### SEO & Marketing
- **Schema Markup**: JSON-LD structured data for articles and products
- **Social Sharing**: Built-in social media sharing functionality
- **Affiliate Link Management**: JavaScript-based external link handling
- **Legal Pages**: Complete legal compliance with privacy policy, terms, and disclaimers

## Data Flow

1. **Static Content Rendering**: Articles and product data are stored in TypeScript files and rendered statically
2. **Client-Side Navigation**: Wouter handles routing without server round-trips
3. **Form Submissions**: Contact and comment forms simulate submission with toast feedback
4. **External Redirects**: Product links use JavaScript handlers to open affiliate URLs in new tabs
5. **SEO Data Injection**: Dynamic meta tags and schema markup injection based on page content

## External Dependencies

### Database & Storage
- **PostgreSQL**: Configured via Drizzle ORM for future user data and comments
- **Neon Database**: Serverless PostgreSQL provider integration ready

### Third-Party Services
- **BossHorn.com**: Primary affiliate partner for product sales
- **Font Awesome**: Icon system for UI elements
- **Google Fonts**: Inter font family for typography

### Development Tools
- **Replit Integration**: Cartographer and runtime error overlay for development
- **PostCSS**: CSS processing with Tailwind and Autoprefixer
- **ESBuild**: Production bundling for server-side code

## Deployment Strategy

### Build Process
1. **Client Build**: Vite builds the React application to `dist/public`
2. **Server Build**: ESBuild bundles the Express server to `dist/index.js`
3. **Static Asset Serving**: Production server serves built client from Express

### Environment Configuration
- **Development**: Vite dev server with HMR and Express API integration
- **Production**: Express serves static files with API routes
- **Database**: Environment-based PostgreSQL connection via DATABASE_URL

### Performance Optimization
- **Code Splitting**: Automatic route-based code splitting
- **Asset Optimization**: Vite handles CSS/JS minification and bundling
- **Image Optimization**: External CDN usage for product images (BossHorn CDN)
- **Caching Strategy**: Static asset caching with proper cache headers

The application is designed to be easily deployable on platforms like Replit, Vercel, or traditional hosting providers with PostgreSQL support.