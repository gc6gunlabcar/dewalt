export interface Product {
  id: string;
  name: string;
  subtitle: string;
  image: string;
  features: string[];
  stars: string;
  rating: string;
  url: string;
  description: string;
  pros: string[];
  cons: string[];
}

export const products: Product[] = [
  {
    id: 'extreme-series',
    name: 'DeWalt Train Horn 20v - Extreme Series',
    subtitle: 'Loudest Train Horn. Top of the line',
    image: 'https://bosshorn.com/cdn/shop/files/dewalt-train-horn-20v-extreme-series-873992.jpg',
    features: [
      '2 Remotes (2000ft range)',
      'Long Metal trumpets - 2 sizes',
      'Ready to go out of box'
    ],
    stars: '★★★★★',
    rating: '5.0',
    url: 'https://bosshorn.com/products/dewalt-train-horn-extreme',
    description: 'The ultimate DeWalt train horn experience with professional-grade performance and maximum sound output.',
    pros: [
      'Loudest horn in the lineup at 150dB',
      'Extended 2000ft remote range',
      'Premium long metal trumpets',
      'Instant activation with no delay',
      'Professional build quality'
    ],
    cons: [
      'Higher price point',
      'Requires DeWalt 20V battery (sold separately)',
      'May be too loud for residential areas'
    ]
  },
  {
    id: 'quad-train-horn',
    name: 'DeWalt Quad Train Horn 20v',
    subtitle: 'Fully built and tested',
    image: 'https://bosshorn.com/cdn/shop/files/dewalt-train-horn-20v-air-horn-gun-201131.jpg',
    features: [
      'Remote Included (up to 160ft)',
      'Metal trumpets - 4 sizes',
      '1-Year Warranty'
    ],
    stars: '★★★★☆',
    rating: '4.8',
    url: 'https://bosshorn.com/products/dewalt-train-horn',
    description: 'Four-trumpet design delivers rich, full train horn sound with excellent build quality and reliability.',
    pros: [
      'Four different trumpet sizes for rich sound',
      'Comprehensive 1-year warranty',
      'Fully assembled and tested',
      'Good value for money',
      'Reliable remote control'
    ],
    cons: [
      'Shorter remote range (160ft)',
      'Slightly less powerful than Extreme Series',
      'Heavier due to four trumpets'
    ]
  },
  {
    id: 'air-horn-gun',
    name: 'DeWalt Air Horn Gun with 5 Trumpets',
    subtitle: 'Ready for use without setup',
    image: 'https://bosshorn.com/cdn/shop/products/dewalt-train-horn-gun-with-5-trumpets-and-remote-931423.jpg',
    features: [
      'Remote Control (up to 160ft)',
      'Durable metal trumpets',
      'No additional setup'
    ],
    stars: '★★★★☆',
    rating: '4.7',
    url: 'https://bosshorn.com/products/dewalt-air-horn',
    description: 'Five-trumpet configuration provides the most complex and rich train horn sound experience available.',
    pros: [
      'Five trumpets for complex sound',
      'Gun-style design for easy handling',
      'Zero setup required',
      'Durable metal construction',
      'Great for mobile use'
    ],
    cons: [
      'Bulkier than other models',
      'More trumpets mean more maintenance',
      '160ft remote range limitation'
    ]
  },
  {
    id: 'dual-train-horn',
    name: 'DeWalt Dual Train Horn',
    subtitle: 'Fully built, no drill needed',
    image: 'https://bosshorn.com/cdn/shop/products/dewalt-impact-train-horn-dual-bosshorn-164565.jpg',
    features: [
      'Remote Included (up to 160ft)',
      'Metal trumpets - 2 sizes',
      '1-Year Warranty'
    ],
    stars: '★★★★☆',
    rating: '4.6',
    url: 'https://bosshorn.com/products/dewalt-impact-train-horn',
    description: 'Compact dual-trumpet design perfect for those who want authentic train horn sound without the bulk.',
    pros: [
      'Compact and lightweight',
      'Easy to transport and store',
      'Authentic dual-tone sound',
      '1-year warranty included',
      'Budget-friendly option'
    ],
    cons: [
      'Lower sound output than larger models',
      'Only two trumpets',
      'Basic remote functionality'
    ]
  }
];

export const getProductById = (id: string): Product | undefined => {
  return products.find(product => product.id === id);
};

export const getProductByName = (name: string): Product | undefined => {
  return products.find(product => 
    product.name.toLowerCase().includes(name.toLowerCase())
  );
};
