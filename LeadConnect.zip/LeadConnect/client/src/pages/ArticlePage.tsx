import { useEffect, useState } from 'react';
import { useParams, Link } from 'wouter';
import { products } from '../data/products';
import SEOHead from '@/components/SEOHead';
import CommentForm from '@/components/CommentForm';
import { getArticleBySlug, getRelatedArticles } from '@/data/articles';
import { generateSchemaMarkup, injectSchemaMarkup } from '@/utils/seo';

export default function ArticlePage() {
  const { slug } = useParams();
  const [article, setArticle] = useState<any>(null);
  const [relatedArticles, setRelatedArticles] = useState<any[]>([]);

  useEffect(() => {
    if (slug) {
      const foundArticle = getArticleBySlug(slug);
      if (foundArticle) {
        setArticle(foundArticle);
        setRelatedArticles(getRelatedArticles(foundArticle.id));
        
        // Set up SEO schema
        const schema = generateSchemaMarkup('article', foundArticle);
        injectSchemaMarkup(schema);
      }
    }
  }, [slug]);

  const handleCheckPrice = (url: string) => {
    window.open(url, '_blank');
  };

  if (!article) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Article Not Found</h1>
          <Link href="/reviews" className="text-primary hover:text-yellow-600">
            ← Back to Reviews
          </Link>
        </div>
      </div>
    );
  }

  const currentUrl = `https://dewalttrainhorn.com/reviews/${article.slug}`;

  return (
    <>
      <SEOHead
        title={article.seo.title}
        description={article.seo.description}
        keywords={article.seo.keywords}
        canonical={currentUrl}
        article={true}
        author={article.author.name}
        publishDate={article.publishDate}
        ogImage={article.featuredImage}
      />

      <div className="text-gray-800" style={{fontFamily: 'Lato, sans-serif', backgroundColor: '#f0f2f5', color: '#333'}}>
        {/* Main Content */}
        <main className="container mx-auto px-4 py-8">
          {/* Content Body */}
          <div className="bg-white p-6 md:p-10 rounded-lg shadow-lg">
            
            {/* Feature Image - Desktop */}
            <section className="mb-8 hidden md:block">
              <img 
                src={article.featuredImage}
                alt={article.title}
                className="w-full h-auto rounded-lg object-cover"
              />
            </section>

            {/* Table of Contents */}
            <section className="mb-12">
              <details className="border rounded-lg">
                <summary className="p-4 font-bold text-xl flex justify-between items-center cursor-pointer">
                  <span>In This Review</span>
                  <svg className="icon w-6 h-6 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                  </svg>
                </summary>
                <div className="p-4 border-t">
                  <ul className="space-y-2 list-decimal list-inside">
                    <li><a href="#intro" className="text-gray-800 hover:underline">Why Your Truck Needs a DeWalt Air Horn</a></li>
                    <li><a href="#comparison" className="text-gray-800 hover:underline">Top 5 Air Horns: DeWalt and Competitors</a></li>
                    <li><a href="#reviews" className="text-gray-800 hover:underline">In-Depth Product Reviews</a></li>
                    <li><a href="#winner" className="text-gray-800 hover:underline">The Winner: Best Overall Air Horn</a></li>
                    <li><a href="#buying-guide" className="text-gray-800 hover:underline">A Practical Guide to Choosing an Air Horn</a></li>
                    <li><a href="#faq" className="text-gray-800 hover:underline">Frequently Asked Questions</a></li>
                    <li><a href="#conclusion" className="text-gray-800 hover:underline">Final Verdict</a></li>
                  </ul>
                </div>
              </details>
            </section>

            {/* Introduction */}
            <section className="mb-12 prose max-w-none" id="intro" style={{color: '#495057', lineHeight: '1.7'}}>
              {/* Category Badge */}
              <div className="mb-4">
                <span className="inline-block px-4 py-2 text-sm font-bold text-black rounded" style={{backgroundColor: '#ffc107'}}>
                  CATEGORY: REVIEWS
                </span>
              </div>

              <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6 leading-tight">
                {article.title.includes('DeWalt') ? 'DeWalt Train Horn' : 
                 article.title.includes('Loudest') ? 'Loudest Train Horn for Truck' : 
                 'Train Horn'}
              </h1>
              
              {/* Feature Image - Mobile Only */}
              <div className="mb-8 md:hidden">
                <img 
                  src={article.featuredImage}
                  alt={article.title}
                  className="w-full h-auto rounded-lg object-cover"
                />
              </div>
              
              <div className="flex items-center space-x-4 text-sm text-gray-600 mb-8">
                <span>By <span className="text-yellow-500 font-medium">{article.author.name}</span></span>
                <span>•</span>
                <span>{new Date(article.publishDate).toLocaleDateString('en-US', { 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}</span>
              </div>

              {/* Social Share with Icons */}
              <div className="flex items-center space-x-4 mb-8">
                <span>Share:</span>
                <a href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(currentUrl)}`} target="_blank" rel="noopener noreferrer" 
                   className="inline-flex items-center justify-center w-10 h-10 rounded-full text-white transition-colors duration-200" 
                   style={{backgroundColor: '#1877f2'}}
                   onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#166fe5'}
                   onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#1877f2'}>
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                  </svg>
                </a>
                <a href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(currentUrl)}&text=${encodeURIComponent(article.title)}`} target="_blank" rel="noopener noreferrer"
                   className="inline-flex items-center justify-center w-10 h-10 rounded-full text-white transition-colors duration-200"
                   style={{backgroundColor: '#1da1f2'}}
                   onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#1a91da'}
                   onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#1da1f2'}>
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                  </svg>
                </a>
                <a href={`https://wa.me/?text=${encodeURIComponent(article.title + ' ' + currentUrl)}`} target="_blank" rel="noopener noreferrer"
                   className="inline-flex items-center justify-center w-10 h-10 rounded-full text-white transition-colors duration-200"
                   style={{backgroundColor: '#25d366'}}
                   onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#22c55e'}
                   onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#25d366'}>
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488"/>
                  </svg>
                </a>
                <a href={`https://pinterest.com/pin/create/button/?url=${encodeURIComponent(currentUrl)}&description=${encodeURIComponent(article.title)}`} target="_blank" rel="noopener noreferrer"
                   className="inline-flex items-center justify-center w-10 h-10 rounded-full text-white transition-colors duration-200"
                   style={{backgroundColor: '#bd081c'}}
                   onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#a0071a'}
                   onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#bd081c'}>
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.174-.105-.949-.199-2.403.041-3.439.219-.937 1.219-5.985 1.219-5.985s-.219-.384-.219-.949c0-.905.398-1.578.895-1.578.423 0 .633.219.633.633 0 .384-.219.905-.384 1.414-.219.905.452 1.578 1.358 1.578 1.628 0 2.883-1.714 2.883-4.19 0-2.192-1.578-3.725-3.725-3.725-2.538 0-4.028 1.905-4.028 3.88 0 .774.219 1.601.548 2.051.055.055.055.11.041.219-.055.219-.174.686-.219.905-.055.274-.219.329-.493.219-1.329-.579-2.162-2.403-2.162-3.88 0-3.158 2.295-6.052 6.6-6.052 3.439 0 6.105 2.451 6.105 5.715 0 3.41-2.146 6.15-5.127 6.15-.999 0-1.941-.548-2.295-1.219 0 0-.548 2.069-.658 2.56-.219.905-.905 2.069-1.358 2.796A12.013 12.013 0 0012.017 24c6.624 0 11.99-5.367 11.99-11.987C24.007 5.367 18.641.001 12.017.001"/>
                  </svg>
                </a>
              </div>
              
              <h3 style={{fontSize: '1.75rem', fontWeight: '700', marginBottom: '1rem'}}>Is Your Factory Horn Loud Enough? Probably Not.</h3>
              <p>Let's be honest. The stock horn on your truck is an afterthought. It's a polite little beep designed for city cars, not for a powerful machine that commands the road. When you're merging on the highway, navigating a busy job site, or trying to get someone's attention from a distance, that weak sound just doesn't cut it. You need something that announces your presence with authority. You need a sound that is impossible to ignore.</p>
              <p>This is where the DeWalt Air Horn changes the game. For years, getting a truly loud train horn meant complex installations, wiring, and dedicated air tanks. It was a job for professionals and enthusiasts with deep pockets. But now, thanks to innovative designs that leverage the power tool batteries you already own, getting that earth-shaking sound is easier than ever. These kits offer a simple, powerful, and DIY-friendly solution. This guide will walk you through everything you need to know.</p>
              
              <h3 style={{fontSize: '1.75rem', fontWeight: '700', marginBottom: '1rem', marginTop: '2rem'}}>What Makes DeWalt Train Horns Special?</h3>
              <p>DeWalt train horns aren't just louder versions of your car horn. They're engineered to produce the authentic sound of a locomotive - that deep, resonant blast that carries for miles. The key difference lies in the trumpet design and air pressure systems that recreate the same acoustic principles used by real trains.</p>
              <p>Unlike permanent installations that require complex wiring and dedicated compressor systems, DeWalt's battery-powered approach means you can install a professional-grade train horn in minutes. Simply connect your existing 20V MAX battery, mount the horn assembly, and you're ready to command the road with authentic train horn authority.</p>
              
              <h3 style={{fontSize: '1.75rem', fontWeight: '700', marginBottom: '1rem', marginTop: '2rem'}}>Why Battery-Powered Train Horns Are the Future</h3>
              <p>Traditional train horn installations required extensive modifications to your vehicle. You needed a high-capacity air compressor, storage tank, pressure switches, and custom wiring - often costing thousands and requiring professional installation. The result was permanent modifications that affected your warranty and resale value.</p>
              <p>Battery-powered systems eliminate these concerns entirely. They're completely portable, require no permanent modifications, and deliver comparable sound levels to hardwired systems. You can move them between vehicles, remove them when needed, and enjoy train horn power without the complexity.</p>
            </section>

            {/* Comparison Section */}
            <section className="mb-12 comparison-table" id="comparison">
              <h2 style={{fontSize: '2.25rem', fontWeight: '900', marginBottom: '2rem', textAlign: 'center'}}>Top 5 Air Horns: DeWalt and Competitors</h2>
              <div>
                <div className="table-header hidden md:grid md:grid-cols-4 md:gap-4 p-4" style={{backgroundColor: '#343a40', color: 'white', borderRadius: '0.375rem'}}>
                  <div className="font-bold">Our Top Picks</div>
                  <div className="font-bold text-center">Rating</div>
                  <div className="font-bold text-center">Key Feature</div>
                  <div className="font-bold text-center">Shop</div>
                </div>
                <div className="md:border md:rounded-lg md:border-gray-200">
                  {products.slice(0, 5).map((product, index) => (
                    <div key={product.id} className="product-row md:grid md:grid-cols-4 md:gap-4 md:items-center p-4" style={{borderBottom: index < 4 ? '1px solid #dee2e6' : 'none'}}>
                      <div className="product-cell flex flex-col items-center text-center mb-6 md:mb-0">
                        <img 
                          src={product.image}
                          alt={product.name}
                          className="w-32 h-32 object-cover rounded-md mb-4"
                        />
                        <h4 className="font-bold text-xl mb-2">{product.name}</h4>
                        <span className="badge badge-yellow inline-block px-2 py-1 text-xs font-bold text-center whitespace-nowrap rounded" style={{color: '#212529', backgroundColor: '#ffc107'}}>
                          {index === 0 ? 'Top DeWalt Pick' : index === 1 ? 'Loudest Overall' : index === 2 ? 'Best Value' : index === 3 ? 'Compact DeWalt' : 'Classic Kit'}
                        </span>
                      </div>
                      <div data-label="Rating" className="details-cell flex flex-col items-center w-full py-3 text-yellow-500 font-bold text-2xl">
                        {product.stars}
                      </div>
                      <div data-label="Key Feature" className="details-cell flex flex-col items-center w-full py-3">
                        <span className="font-semibold">
                          {index === 0 ? 'Maximum Volume' : index === 1 ? 'Premium Build' : index === 2 ? 'Loud & Affordable' : index === 3 ? 'Rich Tone' : 'Great Price'}
                        </span>
                      </div>
                      <div data-label="Shop" className="action-cell text-center mt-6 md:mt-0">
                        <button 
                          onClick={() => handleCheckPrice(product.url)}
                          className="green-btn w-full md:w-auto inline-block text-center font-bold py-3 px-6 rounded transition-colors duration-300"
                          style={{backgroundColor: '#28a745', color: 'white'}}
                          onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#218838'}
                          onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#28a745'}
                        >
                          Check Price
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </section>

            {/* In-Depth Reviews */}
            <section className="mb-12 prose max-w-none" id="reviews">
              <h2 style={{fontSize: '2.25rem', fontWeight: '900', marginBottom: '2rem', textAlign: 'center', color: '#333'}}>In-Depth Product Reviews</h2>
              
              {products.slice(0, 4).map((product, index) => (
                <div key={product.id} className="mb-12">
                  <div className="review-card border border-gray-200 rounded-lg overflow-hidden" style={{borderTop: '4px solid #ffc107'}}>
                    <div className="review-card-header p-6" style={{backgroundColor: '#343a40', color: 'white'}}>
                      <h3 className="text-2xl font-bold">{index + 1}. {product.name}</h3>
                    </div>
                    <div className="p-6">
                      <div className="grid md:grid-cols-3 gap-6">
                        <div className="md:col-span-2">
                          <p className="text-gray-600 leading-relaxed mb-4">
                            {index === 0 && product.name.includes('DeWalt Quad') ? 
                              "For the die-hard DeWalt fan, this is the ultimate upgrade. The DeWalt 20v Quad Horn is specifically designed for those already invested in the DeWalt 20V MAX battery ecosystem. It's handcrafted from a genuine DeWalt tool case and features four premium train horn trumpets that deliver an earth-shaking 150+ decibel blast. The compact design makes installation straightforward, while the familiar DeWalt battery interface means you can swap power sources instantly. What sets this apart is the authentic train horn sound - not just loud, but with the deep, resonant tone that commands respect on the road."
                            : index === 1 && product.name.includes('Milwaukee') ?
                              "Milwaukee's entry into the train horn market brings their legendary build quality to automotive accessories. This powerhouse delivers the loudest sound in our comparison at 155+ decibels, thanks to its high-output compressor and premium brass horns. The M18 battery system provides extended runtime, and the rugged construction can handle extreme weather conditions. Installation is more complex than battery-only units, but the payoff is professional-grade performance that rivals permanently installed systems."
                            : index === 2 && product.name.includes('Ryobi') ?
                              "The Ryobi 18V ONE+ Horn represents incredible value in the battery-powered train horn category. While it may not reach the decibel levels of premium units, it still delivers a commanding 140+ dB blast that will get attention when you need it most. The ONE+ battery system is widely available and affordable, making this an excellent entry point for first-time train horn buyers. The compact design installs in minutes, and the lightweight construction won't add unnecessary weight to your vehicle."
                            : index === 3 && product.name.includes('DeWalt Dual') ?
                              "The DeWalt 20v Dual Horn offers the perfect balance of authentic DeWalt styling and practical performance. This compact dual-trumpet design is perfect for those who want authentic train horn sound without the bulk of larger systems. Built into a genuine DeWalt case, it integrates seamlessly with your existing tool collection while delivering 145+ decibels of authority. The two-horn configuration provides rich, harmonious tones that sound like a real locomotive, not just a loud noise."
                            : product.description}
                          </p>
                          
                          {/* Features List */}
                          <h4 className="font-bold text-lg mb-3">Key Features:</h4>
                          <ul className="space-y-2 mb-6">
                            {product.features.map((feature, idx) => (
                              <li key={idx} className="flex items-center">
                                <svg className="w-5 h-5 mr-2" style={{color: '#28a745'}} fill="currentColor" viewBox="0 0 20 20">
                                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"></path>
                                </svg>
                                {feature}
                              </li>
                            ))}
                          </ul>

                          {/* Pros and Cons */}
                          <div className="pros-cons-container grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="pros-box border rounded-lg" style={{borderColor: '#28a745'}}>
                              <div className="pros-header text-white p-3 rounded-t-md" style={{backgroundColor: '#28a745'}}>
                                <h5 className="font-bold">Pros</h5>
                              </div>
                              <div className="p-4">
                                <ul className="space-y-2">
                                  {product.pros.map((pro, idx) => (
                                    <li key={idx} className="flex items-start">
                                      <svg className="w-4 h-4 mr-2 mt-1 flex-shrink-0" style={{color: '#28a745'}} fill="currentColor" viewBox="0 0 20 20">
                                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
                                      </svg>
                                      <span className="text-sm">{pro}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            </div>
                            
                            <div className="cons-box border rounded-lg" style={{borderColor: '#dc3545'}}>
                              <div className="cons-header text-white p-3 rounded-t-md" style={{backgroundColor: '#dc3545'}}>
                                <h5 className="font-bold">Cons</h5>
                              </div>
                              <div className="p-4">
                                <ul className="space-y-2">
                                  {product.cons.map((con, idx) => (
                                    <li key={idx} className="flex items-start">
                                      <svg className="w-4 h-4 mr-2 mt-1 flex-shrink-0" style={{color: '#dc3545'}} fill="currentColor" viewBox="0 0 20 20">
                                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd"></path>
                                      </svg>
                                      <span className="text-sm">{con}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="text-center">
                          <img 
                            src={product.image}
                            alt={product.name}
                            className="w-full max-w-xs mx-auto rounded-lg mb-4"
                          />
                          <div className="bg-gray-50 p-4 rounded-lg">
                            <div className="text-yellow-500 text-2xl font-bold mb-2">{product.stars}</div>
                            <div className="text-sm text-gray-600 mb-4">Overall Rating: {product.rating}/5.0</div>
                            <button 
                              onClick={() => handleCheckPrice(product.url)}
                              className="green-btn w-full py-3 px-6 rounded font-bold transition-colors duration-300"
                              style={{backgroundColor: '#28a745', color: 'white'}}
                              onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#218838'}
                              onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#28a745'}
                            >
                              Check Price
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </section>

            {/* Winner Section */}
            <section className="mb-12 prose max-w-none" id="winner">
              <h2 style={{fontSize: '2.25rem', fontWeight: '900', marginBottom: '2rem', textAlign: 'center', color: '#333'}}>The Winner: Best Overall Train Horn</h2>
              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-6 rounded-lg">
                <h3 className="text-xl font-bold mb-3">🏆 DeWalt 20v Quad Train Horn</h3>
                <p>After extensive testing and comparison, the DeWalt 20v Quad Train Horn emerges as our top choice for most users. It delivers the perfect balance of authentic sound, build quality, and ease of installation that makes it ideal for both first-time buyers and experienced enthusiasts.</p>
              </div>
            </section>

            {/* Buying Guide */}
            <section className="mb-12 prose max-w-none" id="buying-guide">
              <h2 style={{fontSize: '2.25rem', fontWeight: '900', marginBottom: '2rem', textAlign: 'center', color: '#333'}}>A Practical Guide to Choosing a Train Horn</h2>
              
              <h3 style={{fontSize: '1.75rem', fontWeight: '700', marginBottom: '1rem'}}>Consider Your Primary Use Case</h3>
              <p>Different situations require different approaches to train horn selection. Job site work demands maximum reliability and all-weather performance. Highway driving prioritizes pure volume and range. Recreational use might focus on authentic sound quality and ease of use.</p>
              
              <h3 style={{fontSize: '1.75rem', fontWeight: '700', marginBottom: '1rem', marginTop: '2rem'}}>Battery Compatibility Matters</h3>
              <p>If you already own power tools, choosing a train horn that uses your existing battery system provides immediate value. DeWalt users save money by leveraging their 20V MAX investment, while Milwaukee and Ryobi users can follow the same logic with their respective systems.</p>
              
              <h3 style={{fontSize: '1.75rem', fontWeight: '700', marginBottom: '1rem', marginTop: '2rem'}}>Installation Requirements</h3>
              <p>Consider how and where you'll mount your train horn. Truck beds offer easy installation but may require weatherproofing. Hood mounting provides better sound projection but needs more secure mounting hardware. Portable options offer maximum flexibility but require proper storage between uses.</p>
            </section>

            {/* FAQ Section */}
            <section className="mb-12" id="faq">
              <h2 style={{fontSize: '2.25rem', fontWeight: '900', marginBottom: '2rem', textAlign: 'center', color: '#333'}}>Frequently Asked Questions</h2>
              
              <div className="space-y-4">
                <details className="faq-item border rounded-lg">
                  <summary className="flex items-center cursor-pointer p-6 font-bold text-lg">
                    <svg className="icon w-5 h-5 mr-4 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                    How loud are DeWalt train horns compared to regular car horns?
                  </summary>
                  <div className="faq-answer px-6 pb-6 pl-16 text-gray-600">
                    DeWalt train horns produce 140-155+ decibels compared to standard car horns at 100-110 decibels. This represents a massive increase in perceived loudness - about 4-8 times louder than your factory horn.
                  </div>
                </details>
                
                <details className="faq-item border rounded-lg">
                  <summary className="flex items-center cursor-pointer p-6 font-bold text-lg">
                    <svg className="icon w-5 h-5 mr-4 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                    How long does a 20V battery last with continuous use?
                  </summary>
                  <div className="faq-answer px-6 pb-6 pl-16 text-gray-600">
                    A fully charged 20V MAX battery provides approximately 200-300 horn blasts, depending on blast duration and ambient temperature. For typical use patterns, this represents several months of normal operation.
                  </div>
                </details>
                
                <details className="faq-item border rounded-lg">
                  <summary className="flex items-center cursor-pointer p-6 font-bold text-lg">
                    <svg className="icon w-5 h-5 mr-4 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                    Are train horns legal for road use?
                  </summary>
                  <div className="faq-answer px-6 pb-6 pl-16 text-gray-600">
                    Train horn legality varies by location and intended use. Most areas allow train horns for emergency situations and off-road use. Check your local regulations before installation, as some jurisdictions restrict maximum decibel levels for road-legal vehicles.
                  </div>
                </details>
                
                <details className="faq-item border rounded-lg">
                  <summary className="flex items-center cursor-pointer p-6 font-bold text-lg">
                    <svg className="icon w-5 h-5 mr-4 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                    Can I install a DeWalt train horn myself?
                  </summary>
                  <div className="faq-answer px-6 pb-6 pl-16 text-gray-600">
                    Yes! DeWalt train horns are designed for DIY installation. Most users complete installation in 15-30 minutes using basic hand tools. The process involves mounting the horn assembly and connecting the battery - no complex wiring or modifications required.
                  </div>
                </details>
              </div>
            </section>

            {/* Conclusion */}
            <section className="mb-12 prose max-w-none" id="conclusion">
              <h2 style={{fontSize: '2.25rem', fontWeight: '900', marginBottom: '2rem', textAlign: 'center', color: '#333'}}>Final Verdict</h2>
              <p>The DeWalt train horn revolution has made authentic locomotive sound accessible to every truck owner. Whether you choose the flagship Quad Horn or the compact Dual Horn, you're investing in a product that delivers genuine performance, reliable operation, and the satisfaction of commanding the road with authority.</p>
              <p>For most users, we recommend starting with the DeWalt 20v Quad Horn. It offers the best balance of features, performance, and value while leveraging your existing DeWalt battery investment. The authentic sound quality and straightforward installation make it an ideal introduction to the world of train horns.</p>
              <div className="bg-gray-50 p-6 rounded-lg mt-6">
                <p className="font-semibold mb-2">Ready to upgrade your horn?</p>
                <p className="text-sm text-gray-600">Visit BossHorn.com to explore the complete DeWalt train horn collection and find the perfect model for your truck.</p>
              </div>
            </section>

            {/* Author Bio Section */}
            <section className="mb-12 bg-gray-50 p-6 rounded-lg">
              <div className="flex items-start space-x-4">
                <img 
                  src={article.author.image}
                  alt={article.author.name}
                  className="w-16 h-16 rounded-full object-cover flex-shrink-0"
                />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">About the Author</h3>
                  <p className="text-gray-700 leading-relaxed text-sm">
                    {article.author.bio}
                  </p>
                </div>
              </div>
            </section>

            {/* Read Next Section */}
            {relatedArticles.length > 0 && (
              <section className="mb-12">
                <h2 style={{fontSize: '2.25rem', fontWeight: '900', marginBottom: '2rem', textAlign: 'center'}}>Read Next</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {relatedArticles.map((relatedArticle) => (
                    <Link key={relatedArticle.id} href={`/reviews/${relatedArticle.slug}`}>
                      <article className="group bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-all duration-300">
                        <img 
                          src={relatedArticle.featuredImage}
                          alt={relatedArticle.title}
                          className="w-full h-48 object-cover"
                        />
                        <div className="p-4">
                          <h3 className="font-bold text-gray-900 mb-2 text-sm">
                            {relatedArticle.title}
                          </h3>
                          <p className="text-xs text-gray-600 leading-relaxed line-clamp-3">
                            {relatedArticle.excerpt}
                          </p>
                        </div>
                      </article>
                    </Link>
                  ))}
                </div>
              </section>
            )}
          </div>
        </main>

        {/* Comment Form */}
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <CommentForm />
          </div>
        </div>
      </div>
    </>
  );
}
