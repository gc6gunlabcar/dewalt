import { Link } from 'wouter';
import SEOHead from '@/components/SEOHead';

export default function NotFound() {
  const handleShopNow = () => {
    window.open('https://bosshorn.com/collections/dewalt-train-horns', '_blank');
  };

  return (
    <>
      <SEOHead
        title="Page Not Found - DeWalt Train Horn"
        description="The page you're looking for doesn't exist. Explore our DeWalt train horn collection and reviews."
        canonical="https://dewalttrainhorn.com/404"
      />

      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="max-w-md w-full mx-4">
          <div className="text-center">
            {/* 404 Icon */}
            <div className="mb-8">
              <div className="w-24 h-24 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-train text-primary-foreground text-3xl"></i>
              </div>
              <h1 className="text-6xl font-bold text-gray-900 mb-2">404</h1>
              <h2 className="text-2xl font-semibold text-gray-700">Page Not Found</h2>
            </div>

            {/* Message */}
            <p className="text-gray-600 mb-8 leading-relaxed">
              The page you're looking for seems to have taken a different track. 
              Let's get you back on the right path to find the perfect DeWalt train horn.
            </p>

            {/* Action Buttons */}
            <div className="space-y-4">
              <Link href="/" className="block">
                <button className="w-full dewalt-button">
                  <i className="fas fa-home mr-2"></i>
                  Go Home
                </button>
              </Link>
              
              <Link href="/reviews" className="block">
                <button className="w-full dewalt-button-outline">
                  <i className="fas fa-star mr-2"></i>
                  Browse Reviews
                </button>
              </Link>
              
              <button 
                onClick={handleShopNow}
                className="w-full bg-gray-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-gray-700 transition-colors"
              >
                <i className="fas fa-shopping-cart mr-2"></i>
                Shop Now
              </button>
            </div>

            {/* Popular Links */}
            <div className="mt-12 pt-8 border-t border-gray-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Popular Pages</h3>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <Link href="/reviews/dewalt-air-horn" className="text-primary hover:text-yellow-600 transition-colors">
                  DeWalt Air Horn Review
                </Link>
                <Link href="/reviews/dewalt-train-horn-gun" className="text-primary hover:text-yellow-600 transition-colors">
                  Train Horn Gun Review
                </Link>
                <Link href="/about" className="text-primary hover:text-yellow-600 transition-colors">
                  About Us
                </Link>
                <Link href="/contact" className="text-primary hover:text-yellow-600 transition-colors">
                  Contact Us
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
