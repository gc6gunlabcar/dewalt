import SEOHead from '@/components/SEOHead';
import { Link } from 'wouter';

export default function About() {
  return (
    <>
      <SEOHead
        title="About Us - DeWalt Train Horn Expert Reviews & Guides"
        description="Learn about our mission to provide expert DeWalt train horn reviews, buying guides, and professional recommendations for authentic train horn experiences."
        keywords="about dewalt train horn, train horn experts, horn review specialists"
        canonical="https://dewalttrainhorn.com/about"
      />

      <div className="py-20 bg-gray-50 min-h-screen">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="p-8 lg:p-12">
              <h1 className="text-4xl font-bold text-gray-900 mb-6">About DeWalt Train Horn</h1>
              
              <div className="prose prose-lg max-w-none text-gray-700">
                <p className="text-xl leading-relaxed mb-8">
                  Welcome to the ultimate destination for DeWalt train horn reviews, buying guides, and expert recommendations. 
                  We are passionate enthusiasts dedicated to helping you find the perfect train horn for your specific needs.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Our Mission</h2>
                <p className="mb-6">
                  Our mission is to provide comprehensive, unbiased reviews and expert guidance on DeWalt train horn systems. 
                  We understand that choosing the right train horn is an important decision, whether for emergency use, 
                  professional applications, or recreational purposes.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Why Trust Our Reviews?</h2>
                <ul className="list-disc pl-6 mb-6 space-y-2">
                  <li>Extensive hands-on testing of all DeWalt train horn models</li>
                  <li>Expert analysis from professionals with years of experience</li>
                  <li>Unbiased recommendations based on real-world performance</li>
                  <li>Comprehensive buying guides tailored to different use cases</li>
                  <li>Regular updates to reflect the latest models and features</li>
                </ul>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">What We Cover</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-2">Product Reviews</h3>
                    <p className="text-sm">In-depth analysis of every DeWalt train horn model, including performance testing and real-world usage scenarios.</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-2">Buying Guides</h3>
                    <p className="text-sm">Comprehensive guides to help you choose the right horn based on your specific needs and budget.</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-2">Technical Analysis</h3>
                    <p className="text-sm">Expert breakdowns of features, specifications, and performance characteristics.</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h3 className="font-semibold text-gray-900 mb-2">Comparisons</h3>
                    <p className="text-sm">Side-by-side comparisons to help you understand the differences between models.</p>
                  </div>
                </div>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Our Expert Team</h2>
                <p className="mb-6">
                  Our review team consists of experienced professionals from various backgrounds, including automotive specialists, 
                  emergency responders, and audio engineers. This diverse expertise ensures our reviews cover all aspects of 
                  train horn performance and application.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Commitment to Quality</h2>
                <p className="mb-6">
                  We maintain strict editorial standards and independence in our reviews. Our recommendations are based solely 
                  on product performance, quality, and value. We regularly update our content to ensure you have access to 
                  the most current information about DeWalt train horn systems.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Get in Touch</h2>
                <p className="mb-6">
                  Have questions about our reviews or need personalized recommendations? We'd love to hear from you. 
                  Visit our <Link href="/contact" className="text-primary hover:text-yellow-600 font-medium">contact page</Link> to get in touch with our expert team.
                </p>

                <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-xl p-6 text-white mt-8">
                  <h3 className="text-xl font-semibold mb-3">Ready to Find Your Perfect Train Horn?</h3>
                  <p className="mb-4">
                    Explore our comprehensive reviews and find the DeWalt train horn that's right for you.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <Link href="/reviews" className="inline-block">
                      <button className="dewalt-button">
                        Browse Reviews
                      </button>
                    </Link>
                    <button 
                      onClick={() => window.open('https://bosshorn.com/collections/dewalt-train-horns', '_blank')}
                      className="bg-white text-gray-900 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
                    >
                      Shop Now
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
