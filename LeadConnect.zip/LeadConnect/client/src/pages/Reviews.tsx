import { Link } from 'wouter';
import SEOHead from '@/components/SEOHead';
import { articles } from '@/data/articles';

export default function Reviews() {
  return (
    <>
      <SEOHead
        title="DeWalt Train Horn Reviews & Buying Guides 2025"
        description="Expert reviews and buying guides for DeWalt train horns. In-depth analysis, comparisons, and professional recommendations for all models."
        keywords="dewalt train horn reviews, train horn buying guide, air horn reviews, dewalt horn comparison"
        canonical="https://dewalttrainhorn.com/reviews"
      />

      <div className="py-20 bg-gray-50 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              DeWalt Train Horn Reviews
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Expert reviews, buying guides, and comprehensive analysis of all DeWalt train horn models
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {articles.map((article) => (
              <Link key={article.id} href={`/reviews/${article.slug}`}>
                <article className="group bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-200">
                  {/* Featured Image */}
                  <div className="relative overflow-hidden">
                    <img 
                      src={article.featuredImage} 
                      alt={article.title}
                      className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    {/* Category Badge Overlay */}
                    <div className="absolute top-3 left-3">
                      <span className="bg-primary text-primary-foreground px-2 py-1 rounded text-xs font-semibold">
                        {article.category}
                      </span>
                    </div>
                  </div>
                  
                  {/* Article Content */}
                  <div className="p-4">
                    <h2 className="text-lg font-bold text-gray-900 mb-2 group-hover:text-primary transition-colors line-clamp-2">
                      {article.title}
                    </h2>
                    
                    <p className="text-sm text-gray-600 leading-relaxed mb-3 line-clamp-3">
                      {article.excerpt}
                    </p>
                    
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>By {article.author.name}</span>
                      <span>{new Date(article.publishDate).toLocaleDateString('en-US', { 
                        month: 'short', 
                        day: 'numeric',
                        year: 'numeric'
                      })}</span>
                    </div>
                  </div>
                </article>
              </Link>
            ))}
          </div>

          {/* Call to Action */}
          <div className="mt-16 text-center">
            <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-xl p-8 text-white">
              <h2 className="text-3xl font-bold mb-4">Ready to Choose Your DeWalt Train Horn?</h2>
              <p className="text-xl text-gray-300 mb-6">
                Visit our official partner store to explore the complete collection and make your purchase
              </p>
              <button 
                onClick={() => window.open('https://bosshorn.com/collections/dewalt-train-horns', '_blank')}
                className="dewalt-button text-lg"
              >
                Shop DeWalt Train Horns
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
