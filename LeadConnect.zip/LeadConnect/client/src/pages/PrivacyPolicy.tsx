import SEOHead from '@/components/SEOHead';
import { Link } from 'wouter';

export default function PrivacyPolicy() {
  return (
    <>
      <SEOHead
        title="Privacy Policy - DeWalt Train Horn"
        description="Learn how we protect your privacy and handle your personal information on our DeWalt train horn review website."
        keywords="privacy policy, data protection, dewalt train horn privacy"
        canonical="https://dewalttrainhorn.com/privacy-policy"
      />

      <div className="py-20 bg-gray-50 min-h-screen">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="p-8 lg:p-12">
              <h1 className="text-4xl font-bold text-gray-900 mb-6">Privacy Policy</h1>
              
              <p className="text-lg text-gray-600 mb-8">
                Last updated: January 30, 2025
              </p>

              <div className="prose prose-lg max-w-none text-gray-700">
                <p className="text-xl leading-relaxed mb-8">
                  At DeWalt Train Horn, we respect your privacy and are committed to protecting your personal information. 
                  This Privacy Policy explains how we collect, use, and safeguard your information when you visit our website.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Information We Collect</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">Information You Provide</h3>
                <ul className="list-disc pl-6 mb-6 space-y-2">
                  <li>Contact information when you reach out to us (name, email address)</li>
                  <li>Comments and feedback you submit on our articles</li>
                  <li>Information in correspondence you send to us</li>
                  <li>Survey responses or feedback you provide voluntarily</li>
                </ul>

                <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">Information Automatically Collected</h3>
                <ul className="list-disc pl-6 mb-6 space-y-2">
                  <li>IP address and general location information</li>
                  <li>Browser type and version</li>
                  <li>Operating system</li>
                  <li>Pages visited and time spent on our site</li>
                  <li>Referring website information</li>
                  <li>Device information (mobile, desktop, tablet)</li>
                </ul>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">How We Use Your Information</h2>
                <p className="mb-4">We use the information we collect for the following purposes:</p>
                <ul className="list-disc pl-6 mb-6 space-y-2">
                  <li>To respond to your inquiries and provide customer support</li>
                  <li>To improve our website content and user experience</li>
                  <li>To analyze website traffic and usage patterns</li>
                  <li>To prevent fraud and ensure website security</li>
                  <li>To comply with legal obligations</li>
                  <li>To send you updates about our content (only if you opt-in)</li>
                </ul>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Cookies and Tracking Technologies</h2>
                <p className="mb-4">We use cookies and similar technologies to enhance your browsing experience:</p>
                <ul className="list-disc pl-6 mb-6 space-y-2">
                  <li><strong>Essential Cookies:</strong> Required for basic website functionality</li>
                  <li><strong>Analytics Cookies:</strong> Help us understand how visitors use our site</li>
                  <li><strong>Preference Cookies:</strong> Remember your settings and preferences</li>
                </ul>
                <p className="mb-6">
                  You can control cookies through your browser settings. However, disabling certain cookies may affect website functionality.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Information Sharing and Disclosure</h2>
                <p className="mb-4">We do not sell, trade, or rent your personal information to third parties. We may share information in the following circumstances:</p>
                <ul className="list-disc pl-6 mb-6 space-y-2">
                  <li><strong>Service Providers:</strong> With trusted partners who help operate our website</li>
                  <li><strong>Legal Requirements:</strong> When required by law or to protect our rights</li>
                  <li><strong>Business Transfers:</strong> In connection with mergers or acquisitions</li>
                  <li><strong>Affiliate Partners:</strong> Anonymous traffic data for commission purposes</li>
                </ul>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Affiliate Relationships</h2>
                <p className="mb-6">
                  As an affiliate review website, we may earn commissions from purchases made through our partner links. 
                  This does not affect your purchase price or our review integrity. We maintain editorial independence 
                  and only recommend products we genuinely believe provide value to our readers.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Data Security</h2>
                <p className="mb-6">
                  We implement appropriate security measures to protect your personal information against unauthorized 
                  access, alteration, disclosure, or destruction. These measures include encryption, secure servers, 
                  and regular security assessments. However, no internet transmission is 100% secure, and we cannot 
                  guarantee absolute security.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Your Privacy Rights</h2>
                <p className="mb-4">You have the following rights regarding your personal information:</p>
                <ul className="list-disc pl-6 mb-6 space-y-2">
                  <li><strong>Access:</strong> Request information about what personal data we have about you</li>
                  <li><strong>Correction:</strong> Request correction of inaccurate personal information</li>
                  <li><strong>Deletion:</strong> Request deletion of your personal information</li>
                  <li><strong>Portability:</strong> Request a copy of your data in a portable format</li>
                  <li><strong>Opt-out:</strong> Unsubscribe from marketing communications</li>
                </ul>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Children's Privacy</h2>
                <p className="mb-6">
                  Our website is not intended for children under 13 years of age. We do not knowingly collect 
                  personal information from children under 13. If we become aware that we have collected personal 
                  information from a child under 13, we will take steps to delete such information.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Third-Party Links</h2>
                <p className="mb-6">
                  Our website contains links to third-party websites, including our affiliate partners. We are not 
                  responsible for the privacy practices of these external sites. We encourage you to review their 
                  privacy policies before providing any personal information.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Changes to This Privacy Policy</h2>
                <p className="mb-6">
                  We may update this Privacy Policy from time to time to reflect changes in our practices or legal 
                  requirements. We will notify you of any material changes by posting the updated policy on our website 
                  with a new "Last updated" date.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Contact Us</h2>
                <p className="mb-4">
                  If you have any questions about this Privacy Policy or our privacy practices, please contact us at:
                </p>
                <div className="bg-gray-50 rounded-lg p-4 mb-6">
                  <p><strong>Email:</strong> privacy@dewalttrainhorn.com</p>
                  <p><strong>Contact Form:</strong> <Link href="/contact" className="text-primary hover:text-yellow-600">dewalttrainhorn.com/contact</Link></p>
                </div>

                <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-xl p-6 text-white mt-8">
                  <h3 className="text-xl font-semibold mb-3">Questions About Privacy?</h3>
                  <p className="mb-4">
                    We're committed to transparency and protecting your privacy. If you have any concerns or questions, don't hesitate to reach out.
                  </p>
                  <Link href="/contact" className="inline-block">
                    <button className="dewalt-button">
                      Contact Us
                    </button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
