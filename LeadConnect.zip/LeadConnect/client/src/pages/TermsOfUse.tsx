import SEOHead from '@/components/SEOHead';
import { Link } from 'wouter';

export default function TermsOfUse() {
  return (
    <>
      <SEOHead
        title="Terms of Use - DeWalt Train Horn"
        description="Terms and conditions for using our DeWalt train horn review website, including user responsibilities and legal agreements."
        keywords="terms of use, terms and conditions, dewalt train horn terms"
        canonical="https://dewalttrainhorn.com/terms-of-use"
      />

      <div className="py-20 bg-gray-50 min-h-screen">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="p-8 lg:p-12">
              <h1 className="text-4xl font-bold text-gray-900 mb-6">Terms of Use</h1>
              
              <p className="text-lg text-gray-600 mb-8">
                Last updated: January 30, 2025
              </p>

              <div className="prose prose-lg max-w-none text-gray-700">
                <p className="text-xl leading-relaxed mb-8">
                  Welcome to DeWalt Train Horn. By accessing and using our website, you agree to comply with 
                  and be bound by the following terms and conditions. Please read these terms carefully before using our services.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Acceptance of Terms</h2>
                <p className="mb-6">
                  By accessing, browsing, or using dewalttrainhorn.com (the "Website"), you acknowledge that you have 
                  read, understood, and agree to be bound by these Terms of Use and our Privacy Policy. If you do not 
                  agree to these terms, please do not use our website.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Website Description</h2>
                <p className="mb-6">
                  DeWalt Train Horn is an affiliate review website that provides information, reviews, and recommendations 
                  about DeWalt train horn products. We offer expert analysis, buying guides, and educational content to 
                  help users make informed purchasing decisions.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Affiliate Disclosure</h2>
                <p className="mb-4">
                  This website participates in affiliate programs, which means we may earn commissions from purchases 
                  made through our affiliate links. Important points about our affiliate relationships:
                </p>
                <ul className="list-disc pl-6 mb-6 space-y-2">
                  <li>We only recommend products we genuinely believe provide value</li>
                  <li>Affiliate commissions do not influence our review ratings or recommendations</li>
                  <li>We maintain editorial independence and integrity</li>
                  <li>Purchasing through our links does not affect your purchase price</li>
                  <li>We clearly disclose affiliate relationships where applicable</li>
                </ul>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Acceptable Use</h2>
                <p className="mb-4">You agree to use our website only for lawful purposes and in accordance with these Terms. You agree not to:</p>
                <ul className="list-disc pl-6 mb-6 space-y-2">
                  <li>Use the website for any illegal or unauthorized purpose</li>
                  <li>Violate any applicable local, state, national, or international law</li>
                  <li>Transmit or procure the sending of any advertising or promotional material</li>
                  <li>Impersonate or attempt to impersonate the website, employees, or other users</li>
                  <li>Use the website in any way that could damage or overburden our servers</li>
                  <li>Attempt to gain unauthorized access to any part of the website</li>
                  <li>Use automated systems to access the website without permission</li>
                </ul>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Content and Intellectual Property</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">Our Content</h3>
                <p className="mb-4">
                  All content on this website, including but not limited to text, graphics, logos, images, reviews, 
                  and software, is our property or the property of our content suppliers and is protected by copyright 
                  and other intellectual property laws.
                </p>

                <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">User-Generated Content</h3>
                <p className="mb-4">
                  By submitting content to our website (comments, reviews, feedback), you grant us a non-exclusive, 
                  royalty-free, perpetual license to use, modify, and display such content. You represent that:
                </p>
                <ul className="list-disc pl-6 mb-6 space-y-2">
                  <li>You own or have the necessary rights to the content you submit</li>
                  <li>Your content does not violate any third-party rights</li>
                  <li>Your content is accurate and not misleading</li>
                  <li>Your content does not contain illegal or harmful material</li>
                </ul>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Product Information and Reviews</h2>
                <p className="mb-4">
                  We strive to provide accurate and up-to-date information about DeWalt train horn products. However:
                </p>
                <ul className="list-disc pl-6 mb-6 space-y-2">
                  <li>Product specifications and availability may change without notice</li>
                  <li>We are not responsible for changes made by manufacturers</li>
                  <li>Our reviews reflect our opinions based on testing and research</li>
                  <li>Individual experiences with products may vary</li>
                  <li>We recommend verifying current product information before purchase</li>
                </ul>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Third-Party Links and Services</h2>
                <p className="mb-6">
                  Our website contains links to third-party websites and services. We are not responsible for the 
                  content, policies, or practices of these external sites. Your interactions with third-party sites 
                  are governed by their respective terms and privacy policies.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Disclaimers</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">Website Availability</h3>
                <p className="mb-4">
                  We strive to maintain website availability but cannot guarantee uninterrupted access. We reserve 
                  the right to modify, suspend, or discontinue any part of our website at any time.
                </p>

                <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">Information Accuracy</h3>
                <p className="mb-4">
                  While we work to ensure accuracy, we make no warranties about the completeness, reliability, or 
                  accuracy of information on our website. All information is provided "as is" without warranty of any kind.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Limitation of Liability</h2>
                <p className="mb-6">
                  To the fullest extent permitted by law, we shall not be liable for any direct, indirect, incidental, 
                  consequential, or punitive damages arising from your use of our website or any information contained 
                  therein. This includes but is not limited to damages for loss of profits, data, or other intangible losses.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Indemnification</h2>
                <p className="mb-6">
                  You agree to defend, indemnify, and hold harmless DeWalt Train Horn and its affiliates from any 
                  claims, damages, costs, and expenses (including attorney fees) arising from your use of our website 
                  or violation of these Terms of Use.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Privacy</h2>
                <p className="mb-6">
                  Your privacy is important to us. Please review our Privacy Policy, which also governs your use of 
                  our website, to understand our practices regarding the collection and use of your information.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Modifications to Terms</h2>
                <p className="mb-6">
                  We reserve the right to modify these Terms of Use at any time. Changes will be effective immediately 
                  upon posting on our website. Your continued use of the website after changes are posted constitutes 
                  acceptance of the modified terms.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Governing Law</h2>
                <p className="mb-6">
                  These Terms of Use are governed by and construed in accordance with the laws of the United States. 
                  Any disputes arising under these terms shall be subject to the exclusive jurisdiction of the courts 
                  in the United States.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Severability</h2>
                <p className="mb-6">
                  If any provision of these Terms of Use is found to be unenforceable or invalid, that provision will 
                  be limited or eliminated to the minimum extent necessary so that the Terms of Use will otherwise 
                  remain in full force and effect.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Contact Information</h2>
                <p className="mb-4">
                  If you have any questions about these Terms of Use, please contact us:
                </p>
                <div className="bg-gray-50 rounded-lg p-4 mb-6">
                  <p><strong>Email:</strong> legal@dewalttrainhorn.com</p>
                  <p><strong>Contact Form:</strong> <Link href="/contact" className="text-primary hover:text-yellow-600">dewalttrainhorn.com/contact</Link></p>
                </div>

                <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-xl p-6 text-white mt-8">
                  <h3 className="text-xl font-semibold mb-3">Questions About Our Terms?</h3>
                  <p className="mb-4">
                    We're here to help clarify any questions you may have about using our website or these terms.
                  </p>
                  <Link href="/contact" className="inline-block">
                    <button className="dewalt-button">
                      Contact Us
                    </button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
