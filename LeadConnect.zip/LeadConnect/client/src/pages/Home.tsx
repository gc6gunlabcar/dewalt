import { useEffect } from 'react';
import SEOHead from '@/components/SEOHead';
import ProductComparison from '@/components/ProductComparison';
import FAQ from '@/components/FAQ';
import { generateSchemaMarkup, injectSchemaMarkup } from '@/utils/seo';

export default function Home() {
  useEffect(() => {
    const schema = generateSchemaMarkup('homepage');
    injectSchemaMarkup(schema);
  }, []);

  const handleShopNow = () => {
    window.open('https://bosshorn.com/collections/dewalt-train-horns', '_blank');
  };

  const handleViewBestSeller = () => {
    window.open('https://bosshorn.com/products/dewalt-train-horn-extreme', '_blank');
  };

  const scrollToFeatures = () => {
    document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <>
      <SEOHead
        title="Top 4 Best DeWalt Train Horn - Buying Guide 2025"
        description="Discover the loudest DeWalt train horns with up to 150dB sound. Complete buying guide, reviews & comparisons for 2025's best models."
        keywords="dewalt train horn, train horn kit, air horn gun, 150db horn, remote control horn"
        canonical="https://dewalttrainhorn.com"
      />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-gray-900 to-gray-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl lg:text-5xl font-bold mb-6 leading-tight">
                DeWalt Train Horn - 
                <span className="text-primary"> Ultimate Power</span> 
                in Your Hands
              </h1>
              <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                Experience the loudest, most powerful train horns available. Up to 150dB sound with instant activation, remote control, and no installation required.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <button 
                  onClick={handleViewBestSeller}
                  className="dewalt-button text-lg"
                >
                  View Best Seller
                </button>
                <button 
                  onClick={scrollToFeatures}
                  className="dewalt-button-outline text-lg"
                >
                  Learn More
                </button>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://bosshorn.com/cdn/shop/files/dewalt-train-horn-20v-extreme-series-873992.jpg" 
                alt="DeWalt Train Horn Extreme Series" 
                className="w-full rounded-xl shadow-2xl"
              />
              <div className="absolute top-4 right-4 bg-red-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                Best Seller
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Why Choose DeWalt Train Horn?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Professional-grade features that set our train horns apart from the competition
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="text-center p-6 rounded-xl bg-gray-50 hover:shadow-lg transition-shadow">
              <img 
                src="https://bosshorn.com/cdn/shop/files/long-time_ec8ee370-35d6-4a5f-b445-33064941c3c5.jpg" 
                alt="Long battery life feature" 
                className="w-16 h-16 mx-auto mb-4 rounded-lg object-cover"
              />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Attach Battery & Blast</h3>
              <p className="text-gray-600">Simply attach your DeWalt 20V battery and blast for hours without interruption</p>
            </div>
            
            {/* Feature 2 */}
            <div className="text-center p-6 rounded-xl bg-gray-50 hover:shadow-lg transition-shadow">
              <img 
                src="https://bosshorn.com/cdn/shop/files/instant_ea7a957d-ba71-4b9c-942b-c34d08f8ea9a.jpg" 
                alt="Instant activation feature" 
                className="w-16 h-16 mx-auto mb-4 rounded-lg object-cover"
              />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Instant Activation</h3>
              <p className="text-gray-600">No delay, no waiting - immediate response when you need maximum impact</p>
            </div>
            
            {/* Feature 3 */}
            <div className="text-center p-6 rounded-xl bg-gray-50 hover:shadow-lg transition-shadow">
              <img 
                src="https://bosshorn.com/cdn/shop/files/remote1_a05b6d0a-597c-4bf5-a8c6-9b3b19abd335.jpg" 
                alt="Remote control included" 
                className="w-16 h-16 mx-auto mb-4 rounded-lg object-cover"
              />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Remote Control</h3>
              <p className="text-gray-600">Included remote with up to 2000ft range for ultimate convenience</p>
            </div>
            
            {/* Feature 4 */}
            <div className="text-center p-6 rounded-xl bg-gray-50 hover:shadow-lg transition-shadow">
              <img 
                src="https://bosshorn.com/cdn/shop/files/150db-ai_67a803f2-ad4b-412d-8df8-c4c2b658a224.jpg" 
                alt="150dB sound level" 
                className="w-16 h-16 mx-auto mb-4 rounded-lg object-cover"
              />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Up to 150dB Sound</h3>
              <p className="text-gray-600">Authentic train horn sound that commands attention and respect</p>
            </div>
            
            {/* Feature 5 */}
            <div className="text-center p-6 rounded-xl bg-gray-50 hover:shadow-lg transition-shadow">
              <img 
                src="https://bosshorn.com/cdn/shop/files/installation.jpg" 
                alt="No installation required" 
                className="w-16 h-16 mx-auto mb-4 rounded-lg object-cover"
              />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No Installation</h3>
              <p className="text-gray-600">Ready to use straight out of the box - no drilling or mounting required</p>
            </div>
            
            {/* Feature 6 */}
            <div className="text-center p-6 rounded-xl bg-gray-50 hover:shadow-lg transition-shadow">
              <img 
                src="https://bosshorn.com/cdn/shop/files/warranty3_1598554d-5e33-4bac-9ffc-570babe4a5dd.jpg" 
                alt="1 year warranty" 
                className="w-16 h-16 mx-auto mb-4 rounded-lg object-cover"
              />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">1-Year Warranty</h3>
              <p className="text-gray-600">Complete peace of mind with our comprehensive warranty coverage</p>
            </div>
          </div>
        </div>
      </section>

      {/* Product Comparison */}
      <ProductComparison />

      {/* FAQ Section */}
      <FAQ />
    </>
  );
}
