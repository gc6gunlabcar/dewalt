import { useState } from 'react';
import SEOHead from '@/components/SEOHead';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'wouter';

export default function Contact() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1000));

    toast({
      title: "Message Sent Successfully",
      description: "Thank you for contacting us! We'll get back to you within 24 hours.",
      duration: 5000,
    });

    // Reset form
    setName('');
    setEmail('');
    setSubject('');
    setMessage('');
    setIsSubmitting(false);
  };

  return (
    <>
      <SEOHead
        title="Contact Us - DeWalt Train Horn Expert Support"
        description="Get in touch with our DeWalt train horn experts for personalized recommendations, support, and answers to your questions."
        keywords="contact dewalt train horn, horn support, train horn help, expert consultation"
        canonical="https://dewalttrainhorn.com/contact"
      />

      <div className="py-20 bg-gray-50 min-h-screen">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="p-8 lg:p-12">
              <h1 className="text-4xl font-bold text-gray-900 mb-6">Contact Our Experts</h1>
              
              <p className="text-xl text-gray-700 mb-8">
                Have questions about DeWalt train horns? Need personalized recommendations? 
                Our expert team is here to help you find the perfect horn for your needs.
              </p>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                {/* Contact Form */}
                <div>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-6">Send us a Message</h2>
                  
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        id="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="Your full name"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="your@email.com"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-2">
                        Subject *
                      </label>
                      <select
                        id="subject"
                        value={subject}
                        onChange={(e) => setSubject(e.target.value)}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                      >
                        <option value="">Select a topic</option>
                        <option value="product-recommendation">Product Recommendation</option>
                        <option value="technical-support">Technical Support</option>
                        <option value="review-question">Review Question</option>
                        <option value="general-inquiry">General Inquiry</option>
                        <option value="media-partnership">Media/Partnership</option>
                      </select>
                    </div>
                    
                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                        Message *
                      </label>
                      <textarea
                        id="message"
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        required
                        rows={6}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                        placeholder="Tell us how we can help you..."
                      />
                    </div>
                    
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full dewalt-button disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isSubmitting ? (
                        <>
                          <i className="fas fa-spinner fa-spin mr-2"></i>
                          Sending Message...
                        </>
                      ) : (
                        <>
                          <i className="fas fa-paper-plane mr-2"></i>
                          Send Message
                        </>
                      )}
                    </button>
                  </form>
                </div>

                {/* Contact Information */}
                <div>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-6">Get in Touch</h2>
                  
                  <div className="space-y-6">
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center flex-shrink-0">
                        <i className="fas fa-envelope text-primary-foreground"></i>
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-1">Email Support</h3>
                        <p className="text-gray-600">support@dewalttrainhorn.com</p>
                        <p className="text-sm text-gray-500">We respond within 24 hours</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center flex-shrink-0">
                        <i className="fas fa-clock text-primary-foreground"></i>
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-1">Response Time</h3>
                        <p className="text-gray-600">Monday - Friday: 9 AM - 6 PM EST</p>
                        <p className="text-sm text-gray-500">Weekend inquiries answered Monday</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center flex-shrink-0">
                        <i className="fas fa-shopping-cart text-primary-foreground"></i>
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-1">Purchase Support</h3>
                        <p className="text-gray-600">For purchases, visit our partner store</p>
                        <button 
                          onClick={() => window.open('https://bosshorn.com/collections/dewalt-train-horns', '_blank')}
                          className="text-primary hover:text-yellow-600 font-medium text-sm"
                        >
                          Visit BossHorn.com →
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* FAQ Section */}
                  <div className="mt-8 p-6 bg-gray-50 rounded-lg">
                    <h3 className="font-semibold text-gray-900 mb-4">Frequently Asked Questions</h3>
                    <div className="space-y-3 text-sm">
                      <div>
                        <p className="font-medium text-gray-700">Which DeWalt train horn is loudest?</p>
                        <p className="text-gray-600">The Extreme Series produces up to 150dB sound output.</p>
                      </div>
                      <div>
                        <p className="font-medium text-gray-700">Do I need installation?</p>
                        <p className="text-gray-600">No, all DeWalt train horns are ready to use out of the box.</p>
                      </div>
                      <div>
                        <p className="font-medium text-gray-700">What battery do I need?</p>
                        <p className="text-gray-600">All models use standard DeWalt 20V batteries (sold separately).</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Additional Resources */}
              <div className="mt-12 pt-8 border-t border-gray-200">
                <h2 className="text-2xl font-semibold text-gray-900 mb-6">Additional Resources</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Link href="/reviews" className="group">
                    <div className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                      <i className="fas fa-star text-primary text-2xl mb-3"></i>
                      <h3 className="font-semibold text-gray-900 mb-2 group-hover:text-primary">Expert Reviews</h3>
                      <p className="text-sm text-gray-600">Read our comprehensive reviews and buying guides</p>
                    </div>
                  </Link>
                  
                  <Link href="/about" className="group">
                    <div className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                      <i className="fas fa-users text-primary text-2xl mb-3"></i>
                      <h3 className="font-semibold text-gray-900 mb-2 group-hover:text-primary">About Our Team</h3>
                      <p className="text-sm text-gray-600">Learn about our expert review team and methodology</p>
                    </div>
                  </Link>
                  
                  <div className="group cursor-pointer" onClick={() => window.open('https://bosshorn.com/collections/dewalt-train-horns', '_blank')}>
                    <div className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                      <i className="fas fa-shopping-bag text-primary text-2xl mb-3"></i>
                      <h3 className="font-semibold text-gray-900 mb-2 group-hover:text-primary">Shop Products</h3>
                      <p className="text-sm text-gray-600">Browse and purchase authentic DeWalt train horns</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
