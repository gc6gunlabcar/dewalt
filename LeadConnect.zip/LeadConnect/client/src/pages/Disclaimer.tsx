import SEOHead from '@/components/SEOHead';
import { Link } from 'wouter';

export default function Disclaimer() {
  return (
    <>
      <SEOHead
        title="Disclaimer - DeWalt Train Horn Reviews & Information"
        description="Important disclaimers regarding our DeWalt train horn reviews, affiliate relationships, and product information accuracy."
        keywords="disclaimer, affiliate disclosure, dewalt train horn disclaimer"
        canonical="https://dewalttrainhorn.com/disclaimer"
      />

      <div className="py-20 bg-gray-50 min-h-screen">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="p-8 lg:p-12">
              <h1 className="text-4xl font-bold text-gray-900 mb-6">Disclaimer</h1>
              
              <p className="text-lg text-gray-600 mb-8">
                Last updated: January 30, 2025
              </p>

              <div className="prose prose-lg max-w-none text-gray-700">
                <p className="text-xl leading-relaxed mb-8">
                  The information provided on DeWalt Train Horn is for general informational and educational purposes only. 
                  Please read this disclaimer carefully before using our website or acting on any information provided.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Affiliate Disclosure</h2>
                
                <div className="bg-yellow-50 border-l-4 border-primary p-4 mb-6">
                  <p className="font-semibold text-gray-900 mb-2">Important Notice:</p>
                  <p className="text-gray-700">
                    DeWalt Train Horn is a participant in affiliate programs, including partnerships with BossHorn.com 
                    and other retailers. This means we may earn commissions from qualifying purchases made through our links.
                  </p>
                </div>

                <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">How Affiliate Relationships Work</h3>
                <ul className="list-disc pl-6 mb-6 space-y-2">
                  <li>We receive a commission when you purchase products through our affiliate links</li>
                  <li>This commission comes from the retailer, not from your purchase price</li>
                  <li>You pay the same price whether you use our links or not</li>
                  <li>These commissions help us maintain and improve our website</li>
                  <li>Our affiliate relationships do not influence our honest reviews and recommendations</li>
                </ul>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Product Information Disclaimer</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">Accuracy of Information</h3>
                <p className="mb-4">
                  While we strive to provide accurate and up-to-date information about DeWalt train horn products:
                </p>
                <ul className="list-disc pl-6 mb-6 space-y-2">
                  <li>Product specifications, features, and availability may change without notice</li>
                  <li>Manufacturers may update products or discontinue models</li>
                  <li>Prices and promotional offers are subject to change</li>
                  <li>We recommend verifying current product information before making purchases</li>
                  <li>Always consult official manufacturer specifications for the most current details</li>
                </ul>

                <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">Review and Testing Methodology</h3>
                <p className="mb-6">
                  Our reviews are based on our testing methodology, research, and expert analysis. However, individual 
                  experiences with products may vary based on usage conditions, expectations, and specific needs. 
                  We encourage you to consider multiple sources of information before making purchasing decisions.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Safety and Legal Disclaimers</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">Product Safety</h3>
                <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
                  <p className="font-semibold text-red-800 mb-2">Important Safety Notice:</p>
                  <p className="text-red-700">
                    Train horns produce extremely loud sounds (up to 150dB) that can cause permanent hearing damage. 
                    Always use appropriate hearing protection and exercise caution when operating these devices.
                  </p>
                </div>

                <ul className="list-disc pl-6 mb-6 space-y-2">
                  <li>Always wear hearing protection when operating train horns</li>
                  <li>Never aim horns directly at people or animals</li>
                  <li>Be aware of noise ordinances and regulations in your area</li>
                  <li>Use train horns responsibly and considerately</li>
                  <li>Follow all manufacturer safety instructions and guidelines</li>
                </ul>

                <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">Legal Compliance</h3>
                <p className="mb-6">
                  The use of train horns may be subject to local, state, or federal regulations. Users are responsible 
                  for understanding and complying with all applicable laws and regulations in their jurisdiction. 
                  We do not provide legal advice regarding the use of train horns.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Third-Party Relationships</h2>
                
                <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">Manufacturer Relationships</h3>
                <p className="mb-6">
                  DeWalt Train Horn is an independent review website and is not affiliated with, endorsed by, or 
                  sponsored by DeWalt, Stanley Black & Decker, or any train horn manufacturers. DeWalt is a 
                  trademark of Stanley Black & Decker, Inc., used here for descriptive purposes only.
                </p>

                <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">Retailer Relationships</h3>
                <p className="mb-6">
                  We partner with various retailers, including BossHorn.com, to provide access to products we review. 
                  These partnerships are commercial relationships that help support our website operations while 
                  providing value to our readers.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Limitation of Liability</h2>
                <p className="mb-6">
                  The information on this website is provided on an "as is" basis. To the fullest extent permitted by law, 
                  we exclude all representations, warranties, and conditions relating to our website and the use of this website. 
                  We shall not be liable for any damages arising from the use of this website or any information contained herein.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">External Links</h2>
                <p className="mb-6">
                  Our website contains links to external websites operated by third parties. We have no control over 
                  the content and practices of these sites and cannot accept responsibility or liability for their 
                  respective privacy policies or content.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Professional Advice</h2>
                <p className="mb-6">
                  The information provided on our website does not constitute professional advice. You should not rely 
                  solely on this information to make purchasing decisions. We recommend consulting with qualified 
                  professionals when appropriate and always following manufacturer guidelines.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Changes to This Disclaimer</h2>
                <p className="mb-6">
                  We reserve the right to modify this disclaimer at any time. Changes will be effective immediately 
                  upon posting on our website. Please review this disclaimer periodically for any updates.
                </p>

                <h2 className="text-2xl font-semibold text-gray-900 mt-8 mb-4">Contact Information</h2>
                <p className="mb-4">
                  If you have any questions about this disclaimer or need clarification on any matter, please contact us:
                </p>
                <div className="bg-gray-50 rounded-lg p-4 mb-6">
                  <p><strong>Email:</strong> info@dewalttrainhorn.com</p>
                  <p><strong>Contact Form:</strong> <Link href="/contact" className="text-primary hover:text-yellow-600">dewalttrainhorn.com/contact</Link></p>
                </div>

                <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-xl p-6 text-white mt-8">
                  <h3 className="text-xl font-semibold mb-3">Questions About Our Disclaimers?</h3>
                  <p className="mb-4">
                    We're committed to transparency in all our practices. If you need clarification on any disclaimers, please reach out.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <Link href="/contact" className="inline-block">
                      <button className="dewalt-button">
                        Contact Us
                      </button>
                    </Link>
                    <Link href="/privacy-policy" className="inline-block">
                      <button className="bg-white text-gray-900 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
                        Privacy Policy
                      </button>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
