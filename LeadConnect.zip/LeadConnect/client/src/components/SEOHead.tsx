import { useEffect } from 'react';

interface SEOHeadProps {
  title: string;
  description: string;
  keywords?: string;
  canonical?: string;
  ogImage?: string;
  article?: boolean;
  author?: string;
  publishDate?: string;
}

export default function SEOHead({ 
  title, 
  description, 
  keywords, 
  canonical, 
  ogImage,
  article = false,
  author,
  publishDate
}: SEOHeadProps) {
  useEffect(() => {
    // Set document title
    document.title = title;
    
    // Helper function to set meta tag
    const setMetaTag = (name: string, content: string, property = false) => {
      const selector = property ? `meta[property="${name}"]` : `meta[name="${name}"]`;
      let meta = document.querySelector(selector) as HTMLMetaElement;
      
      if (!meta) {
        meta = document.createElement('meta');
        if (property) {
          meta.setAttribute('property', name);
        } else {
          meta.setAttribute('name', name);
        }
        document.head.appendChild(meta);
      }
      meta.content = content;
    };

    // Set canonical link
    const setCanonicalLink = (url: string) => {
      let link = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
      if (!link) {
        link = document.createElement('link');
        link.rel = 'canonical';
        document.head.appendChild(link);
      }
      link.href = url;
    };

    // Basic meta tags
    setMetaTag('description', description);
    setMetaTag('robots', 'index, follow');
    
    if (keywords) {
      setMetaTag('keywords', keywords);
    }

    if (canonical) {
      setCanonicalLink(canonical);
    }

    // Open Graph tags
    setMetaTag('og:title', title, true);
    setMetaTag('og:description', description, true);
    setMetaTag('og:type', article ? 'article' : 'website', true);
    setMetaTag('og:site_name', 'DeWalt Train Horn', true);
    
    if (canonical) {
      setMetaTag('og:url', canonical, true);
    }

    if (ogImage) {
      setMetaTag('og:image', ogImage, true);
    }

    // Twitter Card tags
    setMetaTag('twitter:card', 'summary_large_image');
    setMetaTag('twitter:title', title);
    setMetaTag('twitter:description', description);
    
    if (ogImage) {
      setMetaTag('twitter:image', ogImage);
    }

    // Article specific tags
    if (article && author) {
      setMetaTag('article:author', author, true);
    }
    
    if (article && publishDate) {
      setMetaTag('article:published_time', publishDate, true);
    }

  }, [title, description, keywords, canonical, ogImage, article, author, publishDate]);

  return null;
}
