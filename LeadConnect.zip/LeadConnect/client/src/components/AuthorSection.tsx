interface AuthorSectionProps {
  id?: string;
  name: string;
  title: string;
  bio: string;
  image: string;
}

export default function AuthorSection({ id = "author", name, title, bio, image }: AuthorSectionProps) {
  return (
    <div id={id} className="mt-8 bg-gradient-to-r from-gray-800 to-gray-700 rounded-xl p-6 text-white">
      <div className="flex items-center space-x-4">
        <img 
          src={image} 
          alt={`${name} - ${title}`}
          className="w-16 h-16 rounded-full object-cover"
        />
        <div>
          <h4 className="text-xl font-semibold">{name}</h4>
          <p className="text-gray-300 mb-2">{title}</p>
          <p className="text-sm text-gray-400">
            {bio}
          </p>
        </div>
      </div>
    </div>
  );
}
