interface SocialShareProps {
  title: string;
  url: string;
  className?: string;
}

export default function SocialShare({ title, url, className = "" }: SocialShareProps) {
  const shareOnFacebook = () => {
    const shareUrl = encodeURIComponent(url);
    const shareTitle = encodeURIComponent(title);
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${shareUrl}`, '_blank', 'width=600,height=400');
  };

  const shareOnTwitter = () => {
    const shareUrl = encodeURIComponent(url);
    const shareTitle = encodeURIComponent(title);
    window.open(`https://twitter.com/intent/tweet?url=${shareUrl}&text=${shareTitle}`, '_blank', 'width=600,height=400');
  };

  const shareOnLinkedIn = () => {
    const shareUrl = encodeURIComponent(url);
    window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${shareUrl}`, '_blank', 'width=600,height=400');
  };

  return (
    <div className={`flex items-center space-x-4 ${className}`}>
      <span className="text-sm font-medium text-gray-700">Share:</span>
      <button 
        onClick={shareOnFacebook} 
        className="text-blue-600 hover:text-blue-700 transition-colors"
      >
        <i className="fab fa-facebook text-lg"></i>
      </button>
      <button 
        onClick={shareOnTwitter} 
        className="text-blue-400 hover:text-blue-500 transition-colors"
      >
        <i className="fab fa-twitter text-lg"></i>
      </button>
      <button 
        onClick={shareOnLinkedIn} 
        className="text-blue-700 hover:text-blue-800 transition-colors"
      >
        <i className="fab fa-linkedin text-lg"></i>
      </button>
    </div>
  );
}
