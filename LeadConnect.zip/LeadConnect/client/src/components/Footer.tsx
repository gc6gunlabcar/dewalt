import { Link } from 'wouter';

export default function Footer() {
  const handleShopNow = () => {
    window.open('https://bosshorn.com/collections/dewalt-train-horns', '_blank');
  };

  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo & Description */}
          <div className="md:col-span-2">
            <Link href="/" className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <i className="fas fa-train text-primary-foreground text-lg"></i>
              </div>
              <span className="text-xl font-bold">DeWalt Train Horn</span>
            </Link>
            <p className="text-gray-400 mb-6 max-w-md">
              Your ultimate destination for authentic DeWalt train horns. Professional-grade sound systems with no installation required.
            </p>
            <button 
              onClick={handleShopNow}
              className="dewalt-button"
            >
              Shop Now
            </button>
          </div>
          
          {/* Legal Pages */}
          <div>
            <div className="font-semibold mb-4 text-white">Legal Pages</div>
            <ul className="space-y-2 text-gray-400">
              <li>
                <Link href="/about" className="hover:text-primary transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-primary transition-colors">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="/privacy-policy" className="hover:text-primary transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms-of-use" className="hover:text-primary transition-colors">
                  Terms of Use
                </Link>
              </li>
              <li>
                <Link href="/disclaimer" className="hover:text-primary transition-colors">
                  Disclaimer
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Follow Us */}
          <div>
            <div className="font-semibold mb-4 text-white">Follow Us</div>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <i className="fab fa-facebook text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <i className="fab fa-twitter text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <i className="fab fa-instagram text-xl"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-primary transition-colors">
                <i className="fab fa-youtube text-xl"></i>
              </a>
            </div>
          </div>
        </div>
        
        {/* Bottom Footer */}
        <div className="border-t border-gray-700 mt-12 pt-8 text-center text-gray-400">
          <p>DeWalt Train Horn © | All rights Reserved | 2025</p>
        </div>
      </div>
    </footer>
  );
}
