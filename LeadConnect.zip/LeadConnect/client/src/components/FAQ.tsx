import { useState } from 'react';

interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

const faqData: FAQItem[] = [
  {
    id: 'faq1',
    question: 'How loud are DeWalt train horns?',
    answer: 'DeWalt train horns can reach up to 150dB, which is comparable to a real train horn. This provides authentic train horn sound that commands attention and respect.'
  },
  {
    id: 'faq2',
    question: 'Do I need to install anything?',
    answer: 'No installation required! DeWalt train horns are ready to use straight out of the box. Simply attach your DeWalt 20V battery and you\'re ready to go.'
  },
  {
    id: 'faq3',
    question: 'What\'s the range of the remote control?',
    answer: 'Remote control range varies by model. The Extreme Series offers up to 2000ft range, while other models provide up to 160ft range for convenient operation.'
  },
  {
    id: 'faq4',
    question: 'How long does the battery last?',
    answer: 'With a DeWalt 20V battery, you can blast for hours. The exact duration depends on usage frequency and battery capacity, but expect extended operation time.'
  },
  {
    id: 'faq5',
    question: 'Is there a warranty?',
    answer: 'Yes! We provide a comprehensive 1-year warranty on all Horn Gun models, giving you complete peace of mind with your purchase.'
  }
];

export default function FAQ() {
  const [openFAQ, setOpenFAQ] = useState<string | null>(null);

  const toggleFAQ = (faqId: string) => {
    setOpenFAQ(openFAQ === faqId ? null : faqId);
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-xl text-gray-600">
            Everything you need to know about DeWalt Train Horns
          </p>
        </div>
        
        <div className="space-y-4">
          {faqData.map((faq) => (
            <div key={faq.id} className="border border-gray-200 rounded-lg">
              <button 
                className="w-full text-left px-6 py-4 flex items-center justify-between focus:outline-none hover:bg-gray-50 transition-colors" 
                onClick={() => toggleFAQ(faq.id)}
              >
                <span className="font-semibold text-gray-900">{faq.question}</span>
                <i className={`fas fa-chevron-down text-gray-500 transform transition-transform ${
                  openFAQ === faq.id ? 'rotate-180' : ''
                }`}></i>
              </button>
              {openFAQ === faq.id && (
                <div className="px-6 pb-4">
                  <p className="text-gray-600">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
