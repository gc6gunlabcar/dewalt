import { useState } from 'react';
import { Link, useLocation } from 'wouter';

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [location] = useLocation();

  const handleShopNow = () => {
    window.open('https://bosshorn.com/collections/dewalt-train-horns', '_blank');
  };

  const isActiveRoute = (path: string) => {
    if (path === '/' && location === '/') return true;
    if (path !== '/' && location.startsWith(path)) return true;
    return false;
  };

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <i className="fas fa-train text-primary-foreground text-lg"></i>
              </div>
              <span className="text-xl font-bold text-gray-900">DeWalt Train Horn</span>
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <Link 
              href="/" 
              className={`font-medium transition-colors ${
                isActiveRoute('/') 
                  ? 'text-primary' 
                  : 'text-gray-700 hover:text-primary'
              }`}
            >
              Home
            </Link>
            <Link 
              href="/reviews" 
              className={`font-medium transition-colors ${
                isActiveRoute('/reviews') 
                  ? 'text-primary' 
                  : 'text-gray-700 hover:text-primary'
              }`}
            >
              Reviews
            </Link>
            <Link 
              href="/about" 
              className={`font-medium transition-colors ${
                isActiveRoute('/about') 
                  ? 'text-primary' 
                  : 'text-gray-700 hover:text-primary'
              }`}
            >
              About Us
            </Link>
            <Link 
              href="/contact" 
              className={`font-medium transition-colors ${
                isActiveRoute('/contact') 
                  ? 'text-primary' 
                  : 'text-gray-700 hover:text-primary'
              }`}
            >
              Contact Us
            </Link>
          </nav>
          
          {/* CTA Button */}
          <button 
            onClick={handleShopNow}
            className="hidden md:block dewalt-button"
          >
            Shop Now
          </button>
          
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            <i className={`fas ${isMobileMenuOpen ? 'fa-times' : 'fa-bars'} text-gray-700`}></i>
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <nav className="flex flex-col space-y-4">
              <Link 
                href="/" 
                className={`font-medium transition-colors ${
                  isActiveRoute('/') 
                    ? 'text-primary' 
                    : 'text-gray-700 hover:text-primary'
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Home
              </Link>
              <Link 
                href="/reviews" 
                className={`font-medium transition-colors ${
                  isActiveRoute('/reviews') 
                    ? 'text-primary' 
                    : 'text-gray-700 hover:text-primary'
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Reviews
              </Link>
              <Link 
                href="/about" 
                className={`font-medium transition-colors ${
                  isActiveRoute('/about') 
                    ? 'text-primary' 
                    : 'text-gray-700 hover:text-primary'
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                About Us
              </Link>
              <Link 
                href="/contact" 
                className={`font-medium transition-colors ${
                  isActiveRoute('/contact') 
                    ? 'text-primary' 
                    : 'text-gray-700 hover:text-primary'
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Contact Us
              </Link>
              <button 
                onClick={handleShopNow}
                className="dewalt-button text-left w-fit"
              >
                Shop Now
              </button>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
