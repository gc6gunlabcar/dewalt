import { products } from '../data/products';

export default function ProductComparisonTable() {
  const handleCheckPrice = (url: string) => {
    window.open(url, '_blank');
  };

  return (
    <section className="mb-12 comparison-table" id="comparison">
      <h2 className="text-4xl font-black text-gray-900 mb-6 text-center">Top DeWalt Train Horns: DeWalt and Competitors</h2>
      <div>
        <div className="table-header hidden md:grid md:grid-cols-4 md:gap-4 p-4">
          <div className="font-bold">Our Top Picks</div>
          <div className="font-bold text-center">Rating</div>
          <div className="font-bold text-center">Key Feature</div>
          <div className="font-bold text-center">Shop</div>
        </div>
        <div className="md:border md:rounded-lg md:border-gray-200">
          {products.map((product, index) => (
            <div key={product.id} className="product-row md:grid md:grid-cols-4 md:gap-4 md:items-center p-4">
              <div className="product-cell">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-32 h-32 object-cover rounded-md mb-4"
                />
                <h4 className="font-bold text-xl mb-2">{product.name}</h4>
                <span className="badge badge-yellow">
                  {index === 0 ? 'Top DeWalt Pick' : index === 1 ? 'Loudest Overall' : index === 2 ? 'Best Value' : 'Budget Pick'}
                </span>
              </div>
              <div data-label="Rating" className="details-cell justify-center text-yellow-500 font-bold text-2xl">
                {product.stars}
              </div>
              <div data-label="Key Feature" className="details-cell justify-center">
                <span className="font-semibold">
                  {index === 0 ? 'Maximum Volume' : index === 1 ? 'Premium Build' : index === 2 ? 'Loud & Affordable' : 'Great Price'}
                </span>
              </div>
              <div data-label="Shop" className="action-cell text-center">
                <button 
                  onClick={() => handleCheckPrice(product.url)}
                  className="green-btn w-full md:w-auto"
                >
                  Check Price
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}