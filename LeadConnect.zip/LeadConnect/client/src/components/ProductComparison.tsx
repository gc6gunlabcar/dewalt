import { products } from '@/data/products';

export default function ProductComparison() {
  const handleCheckPrice = (url: string) => {
    window.open(url, '_blank');
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Top 4 DeWalt Train Horn Models
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Compare our most popular models and find the perfect train horn for your needs
          </p>
        </div>
        
        {/* Product Comparison Table */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          {/* Desktop Table */}
          <div className="hidden lg:block overflow-x-auto">
            <table className="w-full">
              <thead className="bg-primary">
                <tr>
                  <th className="px-6 py-4 text-left text-primary-foreground font-semibold">Product</th>
                  <th className="px-6 py-4 text-left text-primary-foreground font-semibold">Key Features</th>
                  <th className="px-6 py-4 text-left text-primary-foreground font-semibold">Rating</th>
                  <th className="px-6 py-4 text-left text-primary-foreground font-semibold">Action</th>
                </tr>
              </thead>
              <tbody>
                {products.map((product, index) => (
                  <tr key={product.id} className={index !== products.length - 1 ? "border-b border-gray-200" : ""}>
                    <td className="px-6 py-6">
                      <div className="flex items-center space-x-4">
                        <img 
                          src={product.image} 
                          alt={product.name}
                          className="w-20 h-20 rounded-lg object-cover"
                        />
                        <div>
                          <h3 className="font-semibold text-gray-900">{product.name}</h3>
                          <p className="text-sm text-gray-600">{product.subtitle}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-6 text-sm text-gray-600">
                      <ul className="space-y-1">
                        {product.features.map((feature, idx) => (
                          <li key={idx}>• {feature}</li>
                        ))}
                      </ul>
                    </td>
                    <td className="px-6 py-6">
                      <div className="flex items-center">
                        <span className="star-rating">{product.stars}</span>
                        <span className="ml-2 text-sm text-gray-600">{product.rating}</span>
                      </div>
                    </td>
                    <td className="px-6 py-6">
                      <button 
                        onClick={() => handleCheckPrice(product.url)}
                        className="dewalt-button"
                      >
                        Check Price
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          {/* Mobile Stacked Cards */}
          <div className="lg:hidden space-y-6 p-6">
            {products.map((product) => (
              <div key={product.id} className="border border-gray-200 rounded-lg p-4">
                <img 
                  src={product.image} 
                  alt={product.name}
                  className="w-full h-48 object-cover rounded-lg mb-4"
                />
                <h3 className="font-semibold text-gray-900 mb-2">{product.name}</h3>
                <p className="text-sm text-gray-600 mb-3">{product.subtitle}</p>
                <div className="flex items-center mb-3">
                  <span className="star-rating">{product.stars}</span>
                  <span className="ml-2 text-sm text-gray-600">{product.rating}</span>
                </div>
                <ul className="text-sm text-gray-600 mb-4 space-y-1">
                  {product.features.map((feature, idx) => (
                    <li key={idx}>• {feature}</li>
                  ))}
                </ul>
                <button 
                  onClick={() => handleCheckPrice(product.url)}
                  className="w-full dewalt-button"
                >
                  Check Price
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
