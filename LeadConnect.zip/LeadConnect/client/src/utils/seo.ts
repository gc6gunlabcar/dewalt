export const generateSchemaMarkup = (page: string, data?: any) => {
  const baseSchema = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": "DeWalt Train Horn",
    "url": "https://dewalttrainhorn.com",
    "potentialAction": {
      "@type": "SearchAction",
      "target": "https://dewalttrainhorn.com/search?q={search_term_string}",
      "query-input": "required name=search_term_string"
    }
  };

  switch (page) {
    case 'homepage':
      return {
        ...baseSchema,
        "@type": "Organization",
        "name": "DeWalt Train Horn",
        "description": "Professional DeWalt train horns with up to 150dB sound. No installation required, remote control included.",
        "sameAs": [
          "https://www.facebook.com/dewalttrainhorn",
          "https://www.twitter.com/dewalttrainhorn",
          "https://www.instagram.com/dewalttrainhorn"
        ]
      };

    case 'article':
      return {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": data.title,
        "description": data.description,
        "author": {
          "@type": "Person",
          "name": data.author.name
        },
        "datePublished": data.publishDate,
        "dateModified": data.publishDate,
        "image": data.featuredImage,
        "publisher": {
          "@type": "Organization",
          "name": "DeWalt Train Horn",
          "logo": {
            "@type": "ImageObject",
            "url": "https://dewalttrainhorn.com/favicon.svg"
          }
        }
      };

    case 'product':
      return {
        "@context": "https://schema.org",
        "@type": "Product",
        "name": data.name,
        "description": data.description,
        "image": data.image,
        "brand": {
          "@type": "Brand",
          "name": "DeWalt"
        },
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": data.rating,
          "bestRating": "5",
          "worstRating": "1"
        }
      };

    default:
      return baseSchema;
  }
};

export const injectSchemaMarkup = (schema: any) => {
  // Remove existing schema markup
  const existingScript = document.querySelector('script[type="application/ld+json"]');
  if (existingScript) {
    existingScript.remove();
  }

  // Add new schema markup
  const script = document.createElement('script');
  script.type = 'application/ld+json';
  script.textContent = JSON.stringify(schema);
  document.head.appendChild(script);
};
